var swiper = new Swiper('.swiper-container', {
  slidesPerView: 4.5,
  grabCursor: true,
  spaceBetween: 70,
  freeMode: true,
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
  },
});
var swiper1 = new Swiper('.s1', {
  slidesPerView: 4.5,
  spaceBetween: 70,
  freeMode: true,
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
  },
});


$(document).ready(function() {
  $('.slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: false
  });
})

$(document).ready(function() {

  //E-mail Ajax Send
  $(".order__form , .order__form1").submit(function() { //Change
    var th = $(this);
    $.ajax({
      type: "POST",
      url: "mail.php", //Change
      data: th.serialize()
    }).done(function() {
      alert("Thank you!");
      setTimeout(function() {
        // Done Functions
        th.trigger("reset");
      }, 1000);
    });
    return false;
  });

});


// GOODS-SLIDER

let arrowLeft = document.getElementsByClassName('arrow-left');
let arrowRight = document.getElementsByClassName('arrow-right');
let mainUl = document.getElementsByClassName('main-ul');
let ul1 = document.getElementById('ul-change_1');
let ul2 = document.getElementById('ul-change_2');
let ul3 = document.getElementById('ul-change_3');
let ul4 = document.getElementById('ul-change_4');
let mainPane = document.getElementById('main-pane');



let arrowLeftArr = [].slice.call(arrowLeft);
let arrowRightArr = [].slice.call(arrowRight);
let mainUlArr = [].slice.call(mainUl);
// let imgWrap = document.getElementsByClassName('img__wrap');
var OurUl1 = [ul1, ul2, ul3, ul4];
console.log(mainUlArr);
var currentPosition = 1;




function NextSlide() {
  for (i = 0; i < mainUlArr.length; i++) {
    mainUlArr[i].innerHTML = '';
    OurUl1[currentPosition].display = "block";
    console.log(OurUl1)
    mainPane.appendChild(OurUl1[currentPosition])
    // var img = document.createElement('img');
    // img.src = OurSliderImages[currentPosition];
    // slider.appendChild(img);

    console.log(currentPosition);
  }
  ++currentPosition;
}


// function PrevSlide() {
//     slider.innerHTML = '';
//     --currentPosition;
//     var img = document.createElement('img');
//     img.src = OurSliderImages[currentPosition];
//     slider.appendChild(img);
//     console.log(currentPosition);
// }
// nextSlide.addEventListener("click", NextSlide);
// prevSlide.addEventListener("click", PrevSlide);



// let imgWrapArr = [].slice.call(imgWrap);

for (i = 0; i < arrowRightArr.length; i++) {
  arrowRightArr[i].addEventListener("click", NextSlide);
  // function right(){



  // let frips1 = document.getElementById('frips_1');
  //   console.log(frips1);
  // frips1.remove();
  // let newImg1 = document.createElement("img");
  // newImg1.src = "../img/img2.jpg";
  // for(i = 0; i<imgWrapArr.length; i++){
  // imgWrapArr[i].appendChild(newImg1);
  // }
  // }



}









// ORDER FORM



let plus = document.getElementById('plus__img1');
let zero = document.getElementById('order__selectff');
let first = document.getElementById('order__selectf');
let second = document.getElementById('order__selects');
let third = document.getElementById('order__selectt');
let pastila = document.getElementsByClassName('select__pastila');
let frips = document.getElementsByClassName('select__frips');
let box = document.getElementsByClassName('select__box');


let pastilaArr = [].slice.call(pastila);
let fripsArr = [].slice.call(frips);
let boxArr = [].slice.call(box);

let count = 1;

zero.onchange = function() {
  let indexSelected = zero.selectedIndex,
    option = zero.querySelectorAll('option')[indexSelected];
  let selectedId = option.getAttribute('id');


  if (selectedId == '1') {
    for (i = 0; i < pastilaArr.length; i++) {
      pastilaArr[i].hidden = false;
    }
    for (i = 0; i < fripsArr.length; i++) {
      fripsArr[i].hidden = true;
    }
    for (i = 0; i < boxArr.length; i++) {
      boxArr[i].hidden = true;
    }
  } else if (selectedId == '2') {
    for (i = 0; i < pastilaArr.length; i++) {
      pastilaArr[i].hidden = true;
    }
    for (i = 0; i < fripsArr.length; i++) {
      fripsArr[i].hidden = false;
    }
    for (i = 0; i < boxArr.length; i++) {
      boxArr[i].hidden = true;
    }
  } else if (selectedId == '3') {
    for (i = 0; i < pastilaArr.length; i++) {
      pastilaArr[i].hidden = true;
    }
    for (i = 0; i < fripsArr.length; i++) {
      fripsArr[i].hidden = true;
    }
    for (i = 0; i < boxArr.length; i++) {
      boxArr[i].hidden = false;
    }
  }
};

let form = document.getElementById('order__form');
let orderWrap = document.getElementById('order__wrap');
plus.addEventListener("click", more);

function more() {
  let newNodez = zero.cloneNode(true);
  newNodez.setAttribute("name", "vid" + count);
  let newNode = first.cloneNode(true);
  newNode.setAttribute("name", "type" + count);
  let newNodes = second.cloneNode(true);
  newNodes.setAttribute("name", "quantity" + count);
  let newNodet = third.cloneNode(true);
  newNodet.setAttribute("name", "weight" + count);
  count++;
  form.appendChild(newNodez);
  form.appendChild(newNode);
  form.appendChild(newNodes);
  form.appendChild(newNodet);
}
